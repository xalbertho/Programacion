import sys
from PyQt6.QtGui import QPixmap, QPalette, QBrush
from PyQt6 import QtWidgets, QtCore, uic

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        uic.loadUi("diseño.ui", self)
        
        # Accede al widget 'inicio' dentro del QStackedWidget
        self.inicio = self.findChild(QtWidgets.QWidget, 'inicio')
        
        # Establece la imagen de fondo para el widget 'inicio'
        self.set_background_image(self.inicio, 'fondo.jpg')
    
    def set_background_image(self, widget, image_path):
        palette = QPalette()
        pixmap = QPixmap(image_path)
        palette.setBrush(QPalette.ColorRole.Window, QBrush(pixmap))
        widget.setAutoFillBackground(True)
        widget.setPalette(palette)

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
