% obtener la correlacion de las señales
clc
clear all
close all

% inciso a
 dt=1e-3;
 t=[-3:dt:5];
% f1=2*pulso_unitario((t-1)/2);
% g1=pulso_unitario((t-2)/4);
% subplot(2,2,1)
% plot(t,f1,'LineWidth',2);
% grid on
% subplot(2,2,2)
% grid on
% plot(t,g1,'LineWidth',2,'Color','r')
% grid on
% subplot(2,2,[3,4])
% [r,m]=xcorr(g1,f1);
% tao=m*dt;
% r=r*dt;
% plot(tao,r,LineStyle="-.",LineWidth=2,color='m')
% grid on

%inciso b%%

% f2=2*pulso_unitario(t/2);
% 
% subplot(2,2,1)
% plot(t,f2);
% 
% subplot(2,2,2)
% g2=(-2*(t-1)).*(pulso_unitario((t-1/2)))
% plot(t,g2);
% 
% subplot(2,2,[3,4])
% [r2,m2]=xcorr(g2,f2);
% tao2=m2*dt;
% r2=r2*dt;
% plot(tao2,r2,LineStyle="-.",LineWidth=2,color='m')

f3=(t+2).*pulso_unitario((t+1)/2)-(2/3)*(t-3).*pulso_unitario((t-3/2)/3)
g3=2*pulso_unitario((t+1)/2)+pulso_unitario((t-1)/2);

subplot(2,2,1)
plot(t,f3)
subplot(2,2,2)
plot(t,g3)

subplot(2,2,[3,4])
[r3,m3]=xcorr(g3,f3);
tao2=m3*dt;
r3=r3*dt;
plot(tao2,r3,LineStyle="-.",LineWidth=2,color='m')




