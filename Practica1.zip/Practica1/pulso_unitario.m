function  sal= pulso_unitario(t)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
sal=ut(t+1/2)-ut(t-1/2)
end