function salida = r(t)
% Esta funcion contiene programada la funcion rampa unitaria

salida=t.*double(t>=0)
end