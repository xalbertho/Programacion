function sal = rampa_unitatia(t)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
sal=t.*pulso_unitario(t-1)
end