function sal = ut(t)
%Esta funcion tiene la finalidad de calcular los valores del escalo
%unitario, para un determinado valor de t ingresado

sal=double(t>=0)
end