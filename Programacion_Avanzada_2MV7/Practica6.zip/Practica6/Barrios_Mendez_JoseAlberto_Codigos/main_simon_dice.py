import sys
from PyQt6.uic import loadUi
from PyQt6.QtGui import QKeyEvent
from PyQt6.QtGui import QMouseEvent
from PyQt6.QtWidgets import QMainWindow, QApplication, QHeaderView, QTableWidgetItem,QMessageBox
from PyQt6 import QtCore, QtWidgets
from PyQt6.QtCore import QPropertyAnimation, QEasingCurve, QThread

from Ui_diseño import *
from PyQt6.QtWidgets import QMainWindow
import random
import time
import pyfirmata, serial
from pyfirmata import Arduino, util

class JuegoThread2(QThread):
    secuenciaGenerada = QtCore.pyqtSignal(list)
    esperarRespuesta = QtCore.pyqtSignal()

    def __init__(self, arduino, a, b, c, d, parent=None):
        super().__init__(parent)
        self.arduino = arduino
        
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.button_pins = [8, 9, 10, 11]  

    def run(self):
        secuencia = []
        while True:

            nuevo_led = random.randint(self.a, self.d)
            secuencia.append(nuevo_led)
            print(secuencia)

            self.enviar_secuencia(secuencia)
            self.secuenciaGenerada.emit(secuencia)

            #respuesta = self.recibir_respuesta(secuencia)
        
            #if respuesta == secuencia:
                # Continuar con el juego
             #   pass
            #else:
                # Terminar el juego
             #   break

    def mover_servo(self, angulo):
        mapped_value = angulo * (180 / 180)
        self.arduino.digital[self.servo].write(mapped_value)
        time.sleep(3)  

    def enviar_secuencia(self, secuencia, duracion_led=0.5):
        for led in secuencia:
            self.arduino.digital[led].write(1)
            time.sleep(duracion_led)
            for i in range(self.a, self.d + 1):
                if i != led:
                    self.arduino.digital[i].write(0)
            time.sleep(0.4)  
        time.sleep(.5) 



    def recibir_respuesta(self, secuencia):
        pins = [self.arduino.get_pin(f'd:{i}:i') for i in range(8, 12)]

        it = util.Iterator(self.arduino)
        it.start()

        time.sleep(1)

        respuesta = [None]*len(secuencia)

        try:
            for i in range(len(pins)): 
                if pins[i].read() == 1:
                    respuesta.append(pins[i])
                
        finally:
            it.running = False  
            self.arduino.exit()

        return respuesta

class JuegoThread(QThread):
    secuenciaGenerada = QtCore.pyqtSignal(list)
    esperarRespuesta = QtCore.pyqtSignal()
 
    actualizarNombreJugador = QtCore.pyqtSignal(str)
    
    def __init__(self, arduino, servo, a, b, c, d,num_jugadores,nombre1,nombre2,nombre3,nombre4,nombre5, parent=None):
        super().__init__(parent)
        self.nombres=[nombre1,nombre2,nombre3,nombre4,nombre5]
        self.numero_jugadores=num_jugadores
        self.arduino = arduino
        self.servo = servo
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.button_pins = [8, 9, 10, 11]
        

    def run(self):
        secuencia = []
        while True:
            angulo_aleatorio = random.randint(0, 180)
            self.mover_servo(angulo_aleatorio)
            jugador_seleccionado = self.mover_servo(angulo_aleatorio)
            self.actualizarNombreJugador.emit(self.nombres[jugador_seleccionado])



            nuevo_led = random.randint(self.a, self.d)
            secuencia.append(nuevo_led)
            print(secuencia)

            self.enviar_secuencia(secuencia)
            self.secuenciaGenerada.emit(secuencia)
            
            # Esperar la respuesta del jugador
            #self.esperarRespuesta.emit()

            #respuesta = self.recibir_respuesta(secuencia)

            # Verificar si la respuesta es correcta
            #if respuesta == secuencia:
                # Continuar con el juego
             #   pass
            #else:
                # Terminar el juego
             #   break

    def mover_servo(self, angulo):
        rango_por_jugador = 180 /self.numero_jugadores
        # Identificar jugador seleccionado según el ángulo
        jugador_seleccionado = int(angulo // rango_por_jugador)

       
        self.arduino.digital[self.servo].write(angulo)
        time.sleep(3)  
        print(jugador_seleccionado)

        return jugador_seleccionado
    def enviar_secuencia(self, secuencia, duracion_led=0.5):
        for led in secuencia:
            self.arduino.digital[led].write(1)
            time.sleep(duracion_led)
            for i in range(self.a, self.d + 1):
                if i != led:
                    self.arduino.digital[i].write(0)
            time.sleep(0.4)  
        time.sleep(.5)  

    def recibir_respuesta(self, secuencia):
        pins = [self.arduino.get_pin(f'd:{pin}:i') for pin in self.button_pins]
        
        it = util.Iterator(self.arduino)
        it.start()
        
        respuesta = []
        tiempo_inicio = time.time()
        tiempo_maximo_respuesta = 10  
        last_button_press_time = 0
        debounce_interval = 0.2 

        try:
            while len(respuesta) < len(secuencia) and (time.time() - tiempo_inicio) < tiempo_maximo_respuesta:
                for i, pin in enumerate(pins):
                    estado = pin.read()
                    if estado == 1 and (time.time() - last_button_press_time) > debounce_interval:
                        respuesta.append(self.button_pins[i]) 
                        last_button_press_time = time.time() 
        finally:
            it.running = False
        print(respuesta)
        return respuesta
    


   
class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self, *parent, **flags) -> None:
        super().__init__(*parent, **flags)
        self.setupUi(self)
        self.stackedWidget.setCurrentIndex(0)
        self.play_5.clicked.connect(self.activar_1jugador)
        self.extremo.clicked.connect(self.activar_mulplay)
        self.exit.clicked.connect(self.close)
        self.jugadores2.clicked.connect(self.player2)
        self.jugadores2.clicked.connect(self.ver_num_jugadores)
        self.jugadores3.clicked.connect(self.player3)
        self.jugadores3.clicked.connect(self.ver_num_jugadores)
        self.jugadores4.clicked.connect(self.player4)
        self.jugadores4.clicked.connect(self.ver_num_jugadores)
        self.jugadores5.clicked.connect(self.player5)
        self.jugadores5.clicked.connect(self.ver_num_jugadores)
        
        
        self.menu_multi.clicked.connect(self.menu_principal)
        self.menu_2p.clicked.connect(self.menu_principal)
        self.menu_3p.clicked.connect(self.menu_principal)
        self.menu_4p.clicked.connect(self.menu_principal)
        self.menu_5p.clicked.connect(self.menu_principal)
        self.menu_s.clicked.connect(self.menu_principal)
        self.menu_r.clicked.connect(self.menu_principal)
        self.scores.clicked.connect(self.ran_king)
        self.scores_2.clicked.connect(self.ran_king)
        self.scores_4.clicked.connect(self.ran_king)
        self.scores_5.clicked.connect(self.ran_king)
        self.scores_6.clicked.connect(self.ran_king)
        self.jugadores1.clicked.connect(self.un_solo_jugador)
        self.menu_puntaje.clicked.connect(self.menu_principal)
        self.play_1.clicked.connect(self.empezar_multi)
        self.play_2.clicked.connect(self.empezar_multi)
        self.play_3.clicked.connect(self.empezar_multi)
        
        self.play_4.clicked.connect(self.empezar_multi)
        self.iniciar_1jugador.clicked.connect(self.iniciar_juego2)
        self.iniciar_multijugador.clicked.connect(self.iniciar_juego)

        self.num_jugadores=0;
        self.nombre_jugador1=""
        self.nombre_jugador2=""
        self.nombre_jugador3=""
        self.nombre_jugador4=""
        self.nombre_jugador5=""


        self.nombre1=''
        self.nombre2=''
        self.nombre3=''
        self.nombre4=''
        self.nombre5=''

        self.a = 2
        self.b = 3
        self.c = 4
        self.d = 5
        self.servo = 6
        self.arduino = pyfirmata.Arduino('COM6')
        self.arduino.digital[self.servo].mode = pyfirmata.SERVO
        self.secuencia_thread = None
    
    def ver_num_jugadores(self):
        sender = self.sender()  
        if sender == self.jugadores2:
            self.num_jugadores = 2
        
        elif sender == self.jugadores3:
            self.num_jugadores = 3
        elif sender == self.jugadores4:
            self.num_jugadores = 4
        elif sender == self.jugadores5:
            self.num_jugadores = 5
        
    def iniciar_juego2(self):
        if self.secuencia_thread is None or not self.secuencia_thread.isRunning():
            self.secuencia_thread = JuegoThread2(self.arduino, self.a, self.b, self.c, self.d)
            self.secuencia_thread.secuenciaGenerada.connect(self.actualizar_secuencia)
            self.secuencia_thread.esperarRespuesta.connect(self.esperar_respuesta)
            self.secuencia_thread.start()


    def iniciar_juego(self):
        if self.secuencia_thread is None or not self.secuencia_thread.isRunning():
            self.secuencia_thread = JuegoThread(self.arduino, self.servo, self.a, self.b, self.c, self.d, self.num_jugadores, self.nombre1, self.nombre2, self.nombre3, self.nombre4, self.nombre5)
            self.secuencia_thread.secuenciaGenerada.connect(self.actualizar_secuencia)
            self.secuencia_thread.esperarRespuesta.connect(self.esperar_respuesta)
            self.secuencia_thread.actualizarNombreJugador.connect(self.actualizarLabelNombreJugador) 
            self.secuencia_thread.start()



    def actualizarLabelNombreJugador(self, nombre):
       self.label_nombre_jugador.setText(nombre)
       
    def actualizar_secuencia(self, secuencia):
       
        print("Nueva secuencia:", secuencia)

    def esperar_respuesta(self):
        print("Ingrese la secuencia:")

    def un_solo_jugador(self):
        self.stackedWidget.setCurrentIndex(1)

    def empezar_multi(self):
        if self.num_jugadores==2:
            self.nombre = self.in_nombre.toPlainText()
            self.nombre2 = self.in_nombre_2.toPlainText()
            if not self.nombre or not self.nombre2:
                QMessageBox.warning(self, "Advertencia", "El nombre del jugador no puede estar vacío.")
            else:
                
                self.stackedWidget.setCurrentIndex(8)

        elif self.num_jugadores==3:
            self.nombre1 = self.in_nombre_3.toPlainText()
            self.nombre2 = self.in_nombre_4.toPlainText()
            self.nombre3= self.in_nombre_5.toPlainText()
            if not self.nombre1 or not self.nombre2 or not self. nombre3:
                QMessageBox.warning(self, "Advertencia", "El nombre del jugador no puede estar vacío.")
            else:
                
                self.stackedWidget.setCurrentIndex(8)
        elif self.num_jugadores==4:
            self.nombre1 = self.in_nombre_6.toPlainText()
            self.nombre2 = self.in_nombre_7.toPlainText()
            self.nombre3=self.in_nombre_8.toPlainText()
            self.nombre4=self.in_nombre_9.toPlainText()
            if not self.nombre1 or not self.nombre2 or not self.nombre3 or not self.nombre4:
                QMessageBox.warning(self, "Advertencia", "El nombre del jugador no puede estar vacío.")
            else:
                self.stackedWidget.setCurrentIndex(8)
        elif self.num_jugadores==5:
            self.nombre1 = self.in_nombre_10.toPlainText()
            self.nombre2 = self.in_nombre_11.toPlainText()
            self.nombre3=self.in_nombre_12.toPlainText()
            self.nombre4=self.in_nombre_13.toPlainText()
            self.nombre5=self.in_nombre_14.toPlainText()
            if not self.nombre1 or not self.nombre2 or not self.nombre3 or not self.nombre4 or not self.nombre5:
                QMessageBox.warning(self, "Advertencia", "El nombre del jugador no puede estar vacío.")
            else:
               
                self.stackedWidget.setCurrentIndex(8)
            
        
    def menu_principal(self):
        self.stackedWidget.setCurrentIndex(0)

    def player2(self):
        self.stackedWidget.setCurrentIndex(4)

    def player3(self):
        self.stackedWidget.setCurrentIndex(5)

    def player4(self):
        self.stackedWidget.setCurrentIndex(6)

    def player5(self):
        self.stackedWidget.setCurrentIndex(7)

    def activar_1jugador(self):
        self.nombre1 = self.in_nombre1.toPlainText()
        if self.nombre1:  # 
            self.stackedWidget.setCurrentIndex(3)
        else:


               
            QMessageBox.warning(self, "Advertencia", "El nombre del jugador no puede estar vacío.")
    def ran_king(self):
        pass
    def activar_mulplay(self):
        self.stackedWidget.setCurrentIndex(2)
        
        

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())