import serial
import time

# Configura el puerto serial (ajusta el nombre del puerto y el baudrate según tu configuración)
ser = serial.Serial('COM6', 9600)

try:
    while True:
        if ser.in_waiting > 0:
            line = ser.readline().decode('utf-8').strip()
            print("Estado del botón:", line)
            time.sleep(0.1)

except KeyboardInterrupt:
    ser.close()  # Cierra la conexión serial al finalizar
    print("Conexión serial cerrada.")
