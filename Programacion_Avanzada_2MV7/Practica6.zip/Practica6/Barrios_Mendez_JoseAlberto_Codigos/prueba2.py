import pyfirmata
import inspect
import time
import random

if not hasattr(inspect, 'getargspec'):
    inspect.getargspec = inspect.getfullargspec
    
board = pyfirmata.Arduino('COM6')

led_pins = [2, 3, 4, 5]  # Pines donde están conectados los LEDs
for pin in led_pins:
    board.digital[pin].mode = pyfirmata.OUTPUT

# Configurar el pin donde está conectado el servo
servo_pin = 6  # Cambiar al pin correcto donde está conectado el servo
board.digital[servo_pin].mode = pyfirmata.SERVO  # Configurar el pin como servo

try:
    num_leds = 1
    while True:
        selected_pins = random.sample(led_pins, num_leds)  # Seleccionar aleatoriamente N LEDs
        for pin in selected_pins:
            board.digital[pin].write(1)  # Encender el LED seleccionado
        
        # Girar servo a 0 grados
        board.digital[servo_pin].write(0)
        print("Girando servo a 0 grados")
        time.sleep(1)

        # Girar servo a 90 grados
        board.digital[servo_pin].write(90)
        print("Girando servo a 90 grados")
        time.sleep(1)

        # Girar servo a 180 grados
        board.digital[servo_pin].write(180)
        print("Girando servo a 180 grados")
        time.sleep(1)

        # Esperar antes de apagar todos los LEDs
        time.sleep(2)
        
        # Apagar los LEDs
        for pin in selected_pins:
            board.digital[pin].write(0)
        
        num_leds += 1  # Incrementar el número de LEDs encendidos en el siguiente ciclo

except KeyboardInterrupt:
    print("\nPrograma terminado manualmente")

# Detener el movimiento del servo al finalizar
board.digital[servo_pin].write(90)

# Cerrar la conexión con Arduino
board.exit()
