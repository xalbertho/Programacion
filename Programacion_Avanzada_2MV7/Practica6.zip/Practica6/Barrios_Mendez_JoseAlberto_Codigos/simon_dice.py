from pyfirmata import Arduino, util
import time

# Especifica el puerto al que está conectado tu Arduino
board = Arduino('COM6')  # Ajusta esto a tu puerto

# Configura el pin digital 8 como entrada
pin = board.get_pin('d:8:i')

# Inicializa el iterador para evitar el overflow de datos
it = util.Iterator(board)
it.start()

# Da tiempo para que el iterador se establezca
time.sleep(1)

try:
    while True:
        button_state = pin.read()  # Lee el estado del botón (True = presionado, None o False = no presionado)
        if button_state is True:
            print("Botón presionado")
        elif button_state is False:
            print("Botón no presionado")
        elif button_state is None:
            print("Estado del botón no disponible")

        # Espera un poco antes de la próxima lectura para evitar saturación
        time.sleep(0.1)

except KeyboardInterrupt:
    # Cierra la conexión con el Arduino al interrumpir el programa
    board.exit()
    print("Programa terminado")
