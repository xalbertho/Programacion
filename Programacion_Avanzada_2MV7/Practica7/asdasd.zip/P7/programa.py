import sys
import socket
from PyQt6 import QtWidgets, QtCore
from PyQt6.QtCore import QPropertyAnimation, QRect
from PyQt6.uic import loadUi
from PyQt6.QtWidgets import QMainWindow, QApplication

'''Server IPv4: 3.136.134.23
Server IPv6: 2600:1f16:ca:1000:fb81:cd52:1744:1467

ssh: ssh ubuntu@3.136.134.23 -i ServerPA.pem

Puerto: 5000'''

class Ingreso(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi('ingreso.ui', self)
        self.iniciar.clicked.connect(self.iniciar_usuario)
        self.setWindowFlag(QtCore.Qt.WindowType.FramelessWindowHint)
        self.setWindowOpacity(1)
        
        self.gripSize = 10
        self.grip = QtWidgets.QSizeGrip(self)
        self.grip.resize(self.gripSize, self.gripSize)
        
        self.arriba.mouseMoveEvent = self.mover_ventana
        self.minBtn.clicked.connect(self.minimizar)
        self.cerrarBtn.clicked.connect(lambda:self.close())
        
        self.registrate.clicked.connect(lambda:self.stackedWidget.setCurrentWidget(self.registrarse))
        self.regresar.clicked.connect(lambda:self.stackedWidget.setCurrentWidget(self.inicio))
        self.registrar.clicked.connect(self.iniciar_usuario)
        
    def iniciar_usuario(self):
        self.diseño = Usuario()
        self.diseño.show()
        self.close()
    
    def minimizar(self):
        self.showMinimized()
    
    def mousePressEvent(self, event):
        self.click_posicion = event.globalPosition()
        
    def mover_ventana(self, event):
        if not self.isMaximized():
            if event.buttons() == QtCore.Qt.MouseButton.LeftButton:
                self.move (self.pos() + event.globalPosition().toPoint() - self.click_posicion.toPoint())
                self.click_posicion = event.globalPosition()
                event.accept()
            

class Usuario(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi('diseño.ui', self)
        self.csesionBtn.clicked.connect(self.inicio_sesion)
        self.setWindowFlag(QtCore.Qt.WindowType.FramelessWindowHint)
        self.setWindowOpacity(1)
        
        self.gripSize = 10
        self.grip = QtWidgets.QSizeGrip(self)
        self.grip.resize(self.gripSize, self.gripSize)
        
        self.arriba.mouseMoveEvent = self.mover_ventana
        self.reducirBtn.hide()
        self.menucentral.hide()
        self.rightmenu.hide()
        self.minBtn.clicked.connect(self.minimizar)
        self.reducirBtn.clicked.connect(self.comprimir)
        self.maxBtn.clicked.connect(self.expandir)
        self.cerrarBtn.clicked.connect(lambda:self.close())
        self.perfilBtn.clicked.connect(lambda:self.stackedWidget_2.setCurrentWidget(self.perfil))
        self.contactosBtn.clicked.connect(lambda:self.stackedWidget_2.setCurrentWidget(self.contactos))
        self.mensajesBtn.clicked.connect(lambda:self.stackedWidget_2.setCurrentWidget(self.mensajes))
        self.editar.clicked.connect(lambda:self.stackedWidget_2.setCurrentWidget(self.editar_perfil))
        self.listo.clicked.connect(lambda:self.stackedWidget_2.setCurrentWidget(self.perfil))
        self.menuBtn.clicked.connect(self.manipular_menu)
        self.ajustesBtn.clicked.connect(self.manipular_ajustes)
        self.infoBtn.clicked.connect(self.manipular_info)
        self.notificacionBtn.clicked.connect(self.manipular_notificacion)
        self.masBtn.clicked.connect(self.manipular_mas)

        self.menu_animacion = QPropertyAnimation(self.menu, b"maximumWidth")
        self.menu_animacion.setDuration(300)
        self.menu_animacion.setEasingCurve(QtCore.QEasingCurve.Type.InOutQuart)

        self.menu_max = 150
        self.menu_min = 50
        self.funcion = True
        
    def inicio_sesion(self):
        self.ingreso = Ingreso()
        self.ingreso.show()
        self.close()

    def minimizar(self):
        self.showMinimized()

    def comprimir(self):
        self.showNormal()
        self.reducirBtn.hide()
        self.maxBtn.show()
        
    def expandir(self):
        self.showMaximized()
        self.maxBtn.hide()
        self.reducirBtn.show()
    
    def resizeEvent(self, event):
        rect = self.rect()
        self.grip.move(rect.right() - self.gripSize, rect.bottom() - self.gripSize)
    
    def mousePressEvent(self, event):
        self.click_posicion = event.globalPosition()
        
    def mover_ventana(self, event):
        if not self.isMaximized():
            if event.buttons() == QtCore.Qt.MouseButton.LeftButton:
                self.move (self.pos() + event.globalPosition().toPoint() - self.click_posicion.toPoint())
                self.click_posicion = event.globalPosition()
                event.accept()
        if event.globalPosition().y() <= 10:
            self.showMaximized()
            self.maxBtn.hide()
            self.reducirBtn.show()
        else:
            self.showNormal()
            self.reducirBtn.hide()
            self.maxBtn.show()
            
    def manipular_menu(self):
        if self.funcion:
            inicio = self.menu_max
            fin = self.menu_min
        else:
            inicio = self.menu_min
            fin = self.menu_max

        self.menu_animacion.setStartValue(inicio)
        self.menu_animacion.setEndValue(fin)
        self.menu_animacion.start()
        self.funcion = not self.funcion
        
    def manipular_ajustes(self):
        if self.menucentral.isVisible():
            self.menucentral.hide()
        else:
            self.menucentral.show()
            self.mainmenu.setCurrentWidget(self.ajustes)
            self.menuinferior.setText("Ajustes")
    
    def manipular_info(self):
        if self.menucentral.isVisible():
            self.menucentral.hide()
        else:
            self.menucentral.show()
            self.mainmenu.setCurrentWidget(self.informacion)
            self.menuinferior.setText("Información")
            
    def manipular_notificacion(self):
        if self.rightmenu.isVisible():
            self.rightmenu.hide()
        else:
            self.rightmenu.show()
            self.stackedWidget.setCurrentWidget(self.notificaciones)
            self.menusuperior.setText("Notificaciones")

    def manipular_mas(self):
        if self.rightmenu.isVisible():
            self.rightmenu.hide()
        else:
            self.rightmenu.show()
            self.stackedWidget.setCurrentWidget(self.mas)
            self.menusuperior.setText("Más...")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    pantalla_ingreso = Ingreso()
    pantalla_ingreso.show()
    sys.exit(app.exec())
