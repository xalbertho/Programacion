from Ui_diseño import *
from PyQt6.QtWidgets import QMainWindow, QApplication
import sys, socket
from PyQt6.QtCore import QThread, pyqtSignal

class ThreadSocket(QThread):
    global connected
    signal_message = pyqtSignal(str)

    def __init__(self, host, port):
        global connected
        super().__init__()
        self.host = host
        self.port = port

    def run(self):
        global connected
        try:
            server.connect((self.host, self.port))
            connected = True

            while connected:
                message = server.recv(BUFFER_SIZE)
                if message:
                    self.signal_message.emit(message.decode("utf-8"))
                else:
                    self.signal_message.emit("<!!disconnected!!>")
                    break
                
        except Exception as e:
            self.signal_message.emit(f"<!!error!!> {str(e)}")
        finally:
            server.close()
            connected = False
        
    def stop(self):
        global connected
        connected = False
        self.wait()

class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self, *parent, **flags) -> None:
        super().__init__(*parent, **flags)
        self.setupUi(self)

        server = '3.136.134.23'
        port = 5000
        self.coneccion = ThreadSocket(server, int(port))
        self.coneccion.signal_message.connect(self.mensage_entrante)
        self.coneccion.start()

        self.perillas.clicked.connect(lambda: self.stackedWidget_2.setCurrentIndex(0))
        self.diales = [self.dial_1, self.dial_2, self.dial_3, self.dial_4, self.dial_5, self.dial_6]
        self.servos = []
        for i, dial in enumerate(self.diales):
            dial.valueChanged.connect(lambda value, index=i: self.mueveServo(value, index))

    def mensage_entrante(self, mensaje):
        print(f"Mensaje recibido: {mensaje}")
        if mensaje.startswith("SERVO:"):
            partes = mensaje.split(":")
            if len(partes) == 3:
                servo_num = int(partes[1])
                valor = int(partes[2])
                if 1 <= servo_num <= len(self.diales):
                    # Desconectamos temporalmente la señal para evitar recursión
                    self.diales[servo_num - 1].valueChanged.disconnect()
                    self.diales[servo_num - 1].setValue(valor)
                    self.mueveServo(valor, servo_num - 1)
                    # Reconectamos la señal
                    self.diales[servo_num - 1].valueChanged.connect(
                        lambda value, index=servo_num-1: self.mueveServo(value, index))
                    print(f"Servo {servo_num} actualizado a: {valor}")

    def mueveServo(self, value, index):
        print(f"Moviendo Servo {index + 1}: {value}")
        if self.servos:
            self.servos[index].write(value)
        
if __name__ == "__main__":
    BUFFER_SIZE = 1024  
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    connected = False
    app = QApplication(sys.argv)
    
    # Descomentar estas líneas si se usa una conexión física con Arduino
    import pyfirmata
    board = pyfirmata.Arduino('COM3')
    it = pyfirmata.util.Iterator(board)
    it.start()
    servo_pins = ['d:2:s', 'd:3:s', 'd:4:s', 'd:5:s', 'd:6:s', 'd:7:s']

    window = MainWindow()
    
    # Descomentar esta sección si se usa una conexión física con Arduino
    for pin in servo_pins:
         window.servos.append(board.get_pin(pin))
    
    window.show()
    sys.exit(app.exec())