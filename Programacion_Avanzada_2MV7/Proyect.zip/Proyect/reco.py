import cv2
import numpy as np

def detect_shapes(image):
    # Convertir a escala de grises
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # Aplicar desenfoque
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    # Detectar bordes
    edges = cv2.Canny(blurred, 50, 150)

    # Encontrar contornos
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:
        # Aproximar el contorno
        epsilon = 0.04 * cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, epsilon, True)

        # Determinar el número de lados
        num_sides = len(approx)

        # Detectar el tipo de figura
        if num_sides == 3:
            shape_name = "Triángulo"
        elif num_sides == 4:
            # Verificar si es un cuadrado o un rectángulo
            x, y, w, h = cv2.boundingRect(approx)
            aspect_ratio = w / float(h)
            if 0.95 <= aspect_ratio <= 1.05:
                shape_name = "Cuadrado"
            else:
                shape_name = "Rectángulo"
        elif num_sides == 5:
            shape_name = "Pentágono"
        elif num_sides == 6:
            shape_name = "Hexágono"
        else:
            shape_name = "Círculo"

        # Dibujar el contorno y el nombre de la figura
        cv2.drawContours(image, [approx], -1, (0, 255, 0), 2)
        x, y = approx[0][0]
        cv2.putText(image, shape_name, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

    return image

# Iniciar la captura de video
cap = cv2.VideoCapture(1)

while True:
    # Leer un frame de la cámara
    ret, frame = cap.read()

    if not ret:
        break

    # Detectar figuras geométricas en el frame
    processed_frame = detect_shapes(frame)

    # Mostrar el frame procesado
    cv2.imshow('Figura Geométrica', processed_frame)

    # Salir del loop al presionar 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Liberar la captura de video y cerrar ventanas
cap.release()
cv2.destroyAllWindows()
